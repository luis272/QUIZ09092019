using system;

namespace QUIZ09092019
{
    class BangunRuang
    {
        public void volume_balok()
        {
            int a, b, c, dan d;                    
            
            a = 2
            b = 3
            c = 4
            d = a* b* c
            {
                Console.WriteLine("nilai a = "+a+" dikali dengan "+b+" dan "+c+" adalah"+d);
                Console.WriteLine("nilai a = "+a+" dikali dengan "+b+" dan "+c+" adalah"+d);
            }

            */

            int Panjang, Lebar, Tinggi, Volume;
            Console.WriteLine("Menghitung Volume Balok");
            Console.WriteLine(".........................");

            Console.WriteLine("Masukkan Panjang");
            Panjang = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Masukkan Lebar");
            Lebar = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Masukkan Tinggi");
            Tinggi = Convert.ToInt32(Console.ReadLine());

            Volume = Panjang * Lebar * Tinggi;

            Console.WriteLine("Volume Balok adalah ="+volume);
        }
   
        public void Volume_kubus ()
        {
            Console.WriteLine("menghitung volume kubus");
            Console.WriteLine(".......................");

            int sisi, volume;
            Console.WriteLine("Masukkan nilai sisi :");
            sisi = Convert.ToInt32(Console.ReadLine());

            volume = sisi * sisi * sisi;

            Console.WriteLine("Volume kubus adalah ="+volume);
        }
    }
}