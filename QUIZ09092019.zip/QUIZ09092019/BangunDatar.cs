using System;

namespace QUIZ09092019
{
    
    class BangunDatar
    {
        public void luas_persegi()
        {
            Console.Writeline("menghitung luas persegi");
            Console.Writeline(".......................");

            int sisi;
            Console.Writeline("masukkan nilai sisi");
            sisi = Convert.ToInt32(Console.Readline());

            int luas = sisi * sisi;

            Console.Writeline("luas persegi adalah ="+luas);
        }

        public void luas_segitiga()
        {
            Console.Writeline("menghitung luas segitiga");
            Console.Writeline("........................");

            int alas,tinggi,a,b,z,luas;
            Console.Writeline("masukkan nilai alas");
            alas = Convert.ToInt32(Console.Readline());

            Console.Writeline("masukkan nilai tinggi");
            tinggi = Convert.ToInt32(Console.Readline());

            a = 1;
            b = 2;

            z = a * alas * tinggi;
            luas = z / b;

            Console.Writeline("luas segitiga adalah ="+luas);
        }

        public void luas_lingkaran ()
        {
            Console.Writeline("menghitung luas lingkaran");
            Console.Writeline(".........................");

            int r,a,b,blmjadi,luas;

            a = 22;
            b = 7;

             Console.Writeline("masukkan nilai ruas");
             r = Convert.ToInt32(Console.Readline());

             blmjadi = a * r * r;
             luas = blmjadi / b;

             Console.Writeline("luas lingkaran adalah ="+luas);
        }
    }
}